/* ================================================================
   ResumeAI — Ollama-powered ATS Analyzer
   GUI & Application Orchestration
   Separated into modular components: ATS_Scoring, Domain_Review, etc.
   ================================================================ */
const { useState, useRef, useCallback, useEffect, useMemo } = React;

const OLLAMA = "http://localhost:11434";
const GROQ_MODEL = "llama-3.3-70b-versatile"; 

/* ── File Extraction helper ─────────────────────────────────── */
async function extractTextFromFile(file, setLoadMsg) {
  const ext = file.name.split(".").pop().toLowerCase();
  
  if (["txt", "md"].includes(ext)) {
    return await file.text();
  }
  
  if (ext === "pdf") {
    setLoadMsg("Reading PDF document...");
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
    let fullText = "";
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      const strings = content.items.map(item => item.str);
      fullText += strings.join(" ") + "\n";
    }
    return fullText;
  }
  
  if (ext === "docx") {
    setLoadMsg("Reading DOCX document...");
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return result.value;
  }
  
  if (["png", "jpg", "jpeg", "webp"].includes(ext)) {
    setLoadMsg("Running OCR on image... This might take a few seconds.");
    const worker = await Tesseract.createWorker('eng');
    const imageUrl = URL.createObjectURL(file);
    const ret = await worker.recognize(imageUrl);
    await worker.terminate();
    URL.revokeObjectURL(imageUrl);
    return ret.data.text;
  }
  
  throw new Error("Unsupported file format.");
}

/* ── Groq helpers ───────────────────────────────────────────── */
async function callGroq(prompt, apiKey) {
  const url = apiKey ? "https://api.groq.com/openai/v1/chat/completions" : "/api/analyze";
  const headers = { "Content-Type": "application/json" };
  if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;

  const r = await fetch(url, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: GROQ_MODEL,
      messages: [{ role: "user", content: prompt }]
    })
  });
  if (!r.ok) {
    const errText = await r.text();
    console.error("Groq API Error:", errText);
    try {
      const errJson = JSON.parse(errText);
      if (errJson.error && errJson.error.message) {
        throw new Error(`Groq error: ${errJson.error.message}`);
      }
    } catch(e) {}
    throw new Error(`Groq error ${r.status}`);
  }
  const d = await r.json();
  return d.choices[0].message.content || "";
}

async function streamGroq(prompt, onToken, apiKey) {
  const url = apiKey ? "https://api.groq.com/openai/v1/chat/completions" : "/api/analyze";
  const headers = { "Content-Type": "application/json" };
  if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;

  const r = await fetch(url, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: GROQ_MODEL,
      messages: [{ role: "user", content: prompt }],
      stream: true
    })
  });
  if (!r.ok) {
    const errText = await r.text();
    console.error("Groq Streaming API Error:", errText);
    try {
      const errJson = JSON.parse(errText);
      if (errJson.error && errJson.error.message) {
        throw new Error(`Groq error: ${errJson.error.message}`);
      }
    } catch(e) {}
    throw new Error(`Groq error ${r.status}`);
  }
  
  const reader = r.body.getReader();
  const dec = new TextDecoder("utf-8");
  let full = "";
  
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    
    const chunk = dec.decode(value, { stream: true });
    const lines = chunk.split("\n").filter(line => line.trim() !== "");
    
    for (const line of lines) {
      if (line === "data: [DONE]") return full;
      if (line.startsWith("data: ")) {
        try {
          const data = JSON.parse(line.slice(6));
          if (data.choices && data.choices[0].delta && data.choices[0].delta.content) {
            full += data.choices[0].delta.content;
            onToken(full);
          }
        } catch {}
      }
    }
  }
  return full;
}

/* ── Ollama helpers ─────────────────────────────────────────── */
async function checkOllama() {
  try {
    const r = await fetch(`${OLLAMA}/api/tags`, { signal: AbortSignal.timeout(2500) });
    if (!r.ok) return { ok: false, models: [] };
    const d = await r.json();
    return { ok: true, models: (d.models || []).map(m => m.name) };
  } catch { return { ok: false, models: [] }; }
}

async function callOllama(model, prompt) {
  const r = await fetch(`${OLLAMA}/api/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, prompt, stream: false })
  });
  if (!r.ok) throw new Error(`Ollama error ${r.status}`);
  const d = await r.json();
  return d.response || "";
}

async function streamOllama(model, prompt, onToken) {
  const r = await fetch(`${OLLAMA}/api/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, prompt, stream: true })
  });
  if (!r.ok) throw new Error(`Ollama error ${r.status}`);
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let full = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    for (const line of dec.decode(value).split("\n").filter(Boolean)) {
      try {
        const obj = JSON.parse(line);
        if (obj.response) { full += obj.response; onToken(full); }
        if (obj.done) return full;
      } catch {}
    }
  }
  return full;
}

function safeJSON(t) {
  try { const m = t.match(/\{[\s\S]*\}/); return m ? JSON.parse(m[0]) : null; }
  catch { return null; }
}

/* ── Score color ────────────────────────────────────────────── */
function scoreColor(s) {
  if (s >= 75) return "#00d4aa";
  if (s >= 50) return "#f5a623";
  return "#ff5c5c";
}
function scoreBadge(s) {
  if (s >= 75) return "badge-high";
  if (s >= 50) return "badge-mid";
  return "badge-low";
}

/* ── Ring SVG ───────────────────────────────────────────────── */
function Ring({ score, size = 88 }) {
  const r = (size - 10) / 2;
  const circ = 2 * Math.PI * r;
  const pct = Math.min(Math.max(score || 0, 0), 100);
  const dash = (pct / 100) * circ;
  const color = scoreColor(pct);
  return (
    <svg className="ring-svg" width={size} height={size}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#222738" strokeWidth="7"/>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="7"
        strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
        transform={`rotate(-90 ${size/2} ${size/2})`}
        style={{ transition: "stroke-dasharray 1.2s cubic-bezier(0.16,1,0.3,1)" }}/>
    </svg>
  );
}

/* ── Footer Component ───────────────────────────────────────── */
function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <span>Made with ❤️ by </span>
        <a href="https://rudra-gupta.vercel.app/" target="_blank" rel="noopener noreferrer" className="footer-link">
          Rudra Gupta | Portfolio
        </a>
      </div>
    </footer>
  );
}

/* ── Markdown Renderer ─────────────────────────────────────── */
function MarkdownText({ text, streaming, active, loading, type = "insights" }) {
  if (loading && !text) {
    return (
      <div className="stream-loading" style={{ padding: '1rem 0' }}>
         <div className="spin-sm"/> Generating {type}...
      </div>
    );
  }
  
  if (!text && !streaming && !loading) {
    return (
      <div style={{ padding: '1rem 0', color: 'var(--text-dim)', fontSize: '13px', fontStyle: 'italic' }}>
        No {type} generated for this section.
      </div>
    );
  }

  const lines = text ? text.split('\n') : [];
  
  return (
    <div className="review-text" style={{ whiteSpace: 'normal', minHeight: '40px' }}>
      {lines.map((line, i) => {
        const t = line.trim();
        if (!t) return <div key={i} style={{ height: '8px' }}/>;
        
        if (t.startsWith('###')) {
          return <h4 key={i} style={{ color: 'var(--text-main)', marginTop: i===0?'0.5rem':'1.5rem', marginBottom: '0.75rem', fontSize: '14px', letterSpacing: '0.05em', textTransform: 'uppercase', borderBottom: '1px solid var(--border-light)', paddingBottom: '4px' }}>{t.replace(/###\s*/, '')}</h4>;
        }
        if (t.startsWith('##')) {
          const upper = t.toUpperCase();
          if (upper.includes('PROJECT') || upper.includes('STRENGTH') || upper.includes('IMPROVEMENT')) return null;
          return <h3 key={i} style={{ color: 'var(--info)', marginTop: i===0?'0.5rem':'1.5rem', marginBottom: '1rem', fontSize: '16px' }}>{t.replace(/##\s*/, '')}</h3>;
        }
        
        if (t.startsWith('- ') || t.startsWith('* ')) {
          let content = t.substring(2);
          const parts = content.split(/(\*\*.*?\*\*)/g);
          return (
            <div key={i} style={{ display: 'flex', gap: '8px', marginBottom: '8px', lineHeight: '1.5', color: 'var(--text-muted)' }}>
              <span style={{ color: 'var(--primary)' }}>•</span>
              <span>
                {parts.map((part, j) => {
                  if (part.startsWith('**') && part.endsWith('**')) {
                    return <strong key={j} style={{ color: 'var(--text-main)' }}>{part.slice(2, -2)}</strong>;
                  }
                  return part;
                })}
              </span>
            </div>
          );
        }
        
        const parts = t.split(/(\*\*.*?\*\*)/g);
        return (
          <div key={i} style={{ marginBottom: '8px', lineHeight: '1.5', color: 'var(--text-muted)' }}>
            {parts.map((part, j) => {
              if (part.startsWith('**') && part.endsWith('**')) {
                return <strong key={j} style={{ color: 'var(--text-main)' }}>{part.slice(2, -2)}</strong>;
              }
              return part;
            })}
          </div>
        );
      })}
      {streaming && active && <span className="cursor" style={{ display: 'inline-block', width: '8px', height: '16px', background: 'var(--primary)', marginLeft: '4px', verticalAlign: 'middle', animation: 'blink 1s step-end infinite' }}/>}
    </div>
  );
}

/* ── Levels config ──────────────────────────────────────────── */
const LEVELS = [
  {
    id: "beginner",
    icon: "🌱",
    name: "Beginner",
    years: "< 1 year",
    desc: "Just starting out — scored on formatting, clarity, education & skills presentation",
    criteria: "under 1 year of experience — evaluate based on formatting, education quality, core skills, and potential. Be objective and critical.",
    scoringRules: "SCORING ETHOS: BE OBJECTIVE. Do not inflate scores. High quality beginners can reach 80+, but mediocre or poorly structured resumes should be in the 30-50 range. Focus on whether they have the fundamental skills for ${finalDomain}."
  },
  {
    id: "intermediate",
    icon: "⚡",
    name: "Intermediate",
    years: "1 – 5 years",
    desc: "Growing professional — scored on impact, quantified results & relevant experience",
    criteria: "1 to 5 years of experience — evaluate based on quantified achievements, project impact, skill relevance, and career progression.",
    scoringRules: "SCORING ETHOS: BE STRICT. Demand quantified impact (numbers, %, $). A score of 50-65 is NORMAL for a solid intermediate resume. Only give 80+ for truly exceptional leadership and clear career growth."
  },
  {
    id: "advanced",
    icon: "🏆",
    name: "Advanced",
    years: "5+ years",
    desc: "Senior professional — scored on leadership, architecture decisions & measurable impact",
    criteria: "5+ years of experience — evaluate based on leadership, strategic impact, domain expertise, and seniority signals.",
    scoringRules: "SCORING ETHOS: BE HARDEST AND MOST CRITICAL. Demand leadership, architecture decisions, and massive measurable results. A score of 40-55 is NORMAL for a senior resume. 80+ is extremely rare and only for industry leaders."
  }
];

/* ── Resume Preview component ───────────────────────────────── */
function ResumePreview({ file, fileURL, pasteText }) {
  if (file && fileURL) {
    const ext = file.name.split(".").pop().toLowerCase();
    if (ext === "pdf") {
      return (
        <div className="resume-preview">
          <iframe src={fileURL} title="Resume PDF"/>
        </div>
      );
    }
    if (["png","jpg","jpeg","webp"].includes(ext)) {
      return (
        <div className="resume-preview" style={{ overflow:"auto", display:"flex", alignItems:"flex-start", justifyContent:"center", padding:"1rem" }}>
          <img src={fileURL} alt="Resume" style={{ maxWidth:"100%", height:"auto", borderRadius:6 }}/>
        </div>
      );
    }
  }
  return (
    <div className="resume-text-view">{pasteText || "No preview available."}</div>
  );
}

/* ================================================================
   MAIN APP
================================================================ */
function App() {
  /* States */
  const [ollamaOk, setOllamaOk]       = useState(false);
  const [checking, setChecking]        = useState(true);
  const [models, setModels]            = useState([]);
  const [model, setModel]              = useState("");

  const [file, setFile]                = useState(null);
  const [fileURL, setFileURL]          = useState("");
  const [pasteText, setPasteText]      = useState("");
  const [drag, setDrag]                = useState(false);
  const [level, setLevel]              = useState("intermediate");
  const [domainMode, setDomainMode]    = useState("auto");
  const [customDomain, setCustomDomain] = useState("");
  const [detectedDomain, setDetectedDomain] = useState("");
  const [processingMode, setProcessingMode] = useState("online"); 
  const [onlineOption, setOnlineOption]       = useState("developer"); 

  const [page, setPage]                = useState("home"); 
  const [loadMsg, setLoadMsg]          = useState("");
  const [loadPct, setLoadPct]          = useState(0);
  const [error, setError]              = useState("");

  const [contact, setContact]          = useState(null);
  const [sections, setSections]        = useState(null);
  const [scores, setScores]            = useState(null);
  const [streaming, setStreaming]      = useState(false);
  const [reviewText, setReviewText]    = useState("");
  const [activeTab, setActiveTab]      = useState("ats"); 
  const [links, setLinks]              = useState(null);
  const [groqKey, setGroqKey]          = useState("");
  const [showKeyInput, setShowKeyInput] = useState(false);
  const [adjacentRoles, setAdjacentRoles] = useState([]);
  const [loadingAbilities, setLoadingAbilities] = useState(false);
  const [waitTime, setWaitTime]        = useState(0); 
  const [isUsingDefaultKey, setIsUsingDefaultKey] = useState(true);
  const [serverKeyAvailable, setServerKeyAvailable] = useState(false);
  const [analyzing, setAnalyzing]      = useState(false);

  const fileRef = useRef();
  const RATE_LIMIT_SECONDS = 60;

  const updateGroqKey = useCallback((key) => {
    setGroqKey(key);
    if (key) {
      localStorage.setItem('resumeai_groq_key', key);
    } else {
      localStorage.removeItem('resumeai_groq_key');
    }
  }, []);

  useEffect(() => {
    checkOllama().then(({ ok, models: m }) => {
      setOllamaOk(ok);
      setChecking(false);
      if (ok) {
        setModels(m);
        const pref = ["llama3.1", "llama3", "mistral", "qwen3", "phi3", "gemma3"];
        const found = pref.find(p => m.some(mm => mm.startsWith(p)));
        setModel(found ? m.find(mm => mm.startsWith(found)) : m[0] || "");
      }
    });
    
    fetch('/api/status')
      .then(r => r.json())
      .then(d => {
        setServerKeyAvailable(d.configured);
        setOnlineOption(d.configured ? "developer" : "personal");
      })
      .catch(() => setServerKeyAvailable(false));

    const savedKey = localStorage.getItem('resumeai_groq_key');
    if (savedKey) setGroqKey(savedKey);
    
    const lastAnalysisTime = localStorage.getItem('resumeai_last_analysis');
    if (lastAnalysisTime && (onlineOption === "developer")) {
      const elapsed = Math.floor((Date.now() - parseInt(lastAnalysisTime)) / 1000);
      const remaining = RATE_LIMIT_SECONDS - elapsed;
      if (remaining > 0) setWaitTime(remaining);
    }
  }, []);
  
  useEffect(() => {
    if (waitTime > 0) {
      const timer = setTimeout(() => setWaitTime(waitTime - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [waitTime]);
  
  useEffect(() => {
    setIsUsingDefaultKey(onlineOption === "developer");
  }, [groqKey, onlineOption]);

  const handleFile = useCallback((f) => {
    if (!f) return;
    setFile(f);
    setFileURL(URL.createObjectURL(f));
    setError("");
  }, []);

  const onDrop = useCallback((e) => {
    e.preventDefault(); setDrag(false);
    handleFile(e.dataTransfer.files[0]);
  }, [handleFile]);

  const levelConfig = useMemo(() => LEVELS.find(l => l.id === level), [level]);

  /* ── Analyze ─────────────────────────────────────────────── */
  async function analyze() {
    if (analyzing) return;
    setAnalyzing(true);
    setError("");
    const hasInput = file || pasteText.trim().length > 50;
    if (!hasInput) { setError("Please upload a resume or paste at least 50 characters of text."); setAnalyzing(false); return; }
    if (processingMode === "offline" && !ollamaOk) { setError("Ollama is not running."); setAnalyzing(false); return; }
    
    setPage("loading");
    setLoadPct(5);
    
    const currentKey = onlineOption === "personal" ? groqKey : null;
    if (onlineOption === "developer" && processingMode === "online") {
      localStorage.setItem('resumeai_last_analysis', Date.now().toString());
      setWaitTime(RATE_LIMIT_SECONDS);
    }

    try {
      let resumeText = pasteText.trim();
      if (file) {
        setLoadMsg("Extracting text...");
        resumeText = await extractTextFromFile(file, setLoadMsg);
      }

      /* Step 0 — Domain Inference */
      let finalDomain = domainMode === "custom" ? customDomain.trim() : domainMode;
      if (domainMode === "auto") {
        setLoadMsg("Detecting role...");
        const domainPrompt = `Determine candidate's target role (e.g. Full Stack Developer, AI & ML Engineer). Return ONLY the role name.\n\nRESUME:\n${resumeText.slice(0, 2000)}`;
        const rawDomain = processingMode === "online" 
          ? await callGroq(domainPrompt, currentKey)
          : await callOllama(model, domainPrompt);
        finalDomain = rawDomain.trim().replace(/^"|"$/g, '');
      }
      setDetectedDomain(finalDomain);

      /* Step 1 — Extract sections */
      setLoadMsg("Parsing resume...");
      const extractPrompt = `Extract sections (contact, links, experience_months, sections: skills, experience, projects, etc) as JSON.\n\nRESUME:\n${resumeText.slice(0, 4000)}`;
      const rawExtract = processingMode === "online" 
          ? await callGroq(extractPrompt, currentKey)
          : await callOllama(model, extractPrompt);
      const parsed = safeJSON(rawExtract);
      if (!parsed) throw new Error("Failed to parse resume.");
      
      setContact(parsed.contact || {});
      setSections(parsed.sections || {});
      setLinks(parsed.links || {});
      setLoadPct(40);

      /* Step 2 — ATS Score (Using ATS_Scoring.js) */
      setLoadMsg("Scoring...");
      const scorePrompt = window.ATS_Scoring.getPrompt(finalDomain, levelConfig, resumeText, parsed);
      const rawScores = processingMode === "online" 
          ? await callGroq(scorePrompt, currentKey)
          : await callOllama(model, scorePrompt);
      let parsedScores = safeJSON(rawScores);
      if (parsedScores) {
        parsedScores = window.ATS_Scoring.applyExperienceBonus(parsedScores, parsed.total_experience_months);
        setScores(parsedScores);
      }
      setLoadPct(70);

      /* Step 3 — Domain Review (Using Domain_Review.js) */
      setLoadMsg("Reviewing...");
      const reviewPrompt = window.Domain_Review.getPrompt(finalDomain, levelConfig, parsed.sections);
      setStreaming(true);
      setPage("analysis");
      setActiveTab("domain");

      try {
        if (processingMode === "online") {
          await streamGroq(reviewPrompt, (text) => setReviewText(text), currentKey);
        } else {
          const rawReview = await callOllama(model, reviewPrompt);
          setReviewText(rawReview);
        }
      } finally {
        setStreaming(false);
      }
      
      /* Step 4 — Abilities (Using Abilities.js) */
      setLoadingAbilities(true);
      try {
        const adjPrompt = window.Abilities.getPrompt(finalDomain, parsed.sections);
        const adjRaw = processingMode === "online" ? await callGroq(adjPrompt, currentKey) : await callOllama(model, adjPrompt);
        const cleaned = window.Abilities.cleanResponse(adjRaw);
        setAdjacentRoles(JSON.parse(cleaned));
      } catch (e) {
        console.error("Abilities error", e);
      } finally {
        setLoadingAbilities(false);
      }
      
      setLoadPct(100);
      setAnalyzing(false);

    } catch (e) {
      setError(e.message);
      setPage("home");
      setAnalyzing(false);
    }
  }

  /* ── GUI Render Logic ──────────────────────────────────── */
  if (page === "home") {
    return (
      <div className="home">
        <div className="home-inner">
          <div className="home-left">
            <div className="home-hero-content"><img src="hero.png" className="home-hero-img" /></div>
            <div className="home-header-left">
              <div className="home-logo">ResumeAI · ATS Analyzer</div>
              <h1 className="home-title">Is your resume <strong>ATS ready?</strong></h1>
            </div>
          </div>
          <div className="home-right">
            <div className="card" style={{ padding: "1rem" }}>
              <div className="tags-row" style={{ justifyContent: "center" }}>
                <div className={`tag ${processingMode === "online" ? "tag-green" : ""}`} onClick={() => setProcessingMode("online")}>Online Engine</div>
                <div className={`tag ${processingMode === "offline" ? "tag-green" : ""}`} onClick={() => setProcessingMode("offline")}>Offline Engine</div>
              </div>
            </div>
            <div className="card">
              <div className="card-label">Resume File</div>
              <div className={`dropzone ${drag ? "active" : ""}`} onClick={() => fileRef.current?.click()} onDragOver={e=>{e.preventDefault();setDrag(true)}} onDragLeave={()=>setDrag(false)} onDrop={onDrop}>
                <input ref={fileRef} type="file" onChange={e=>handleFile(e.target.files[0])} style={{opacity:0,position:"absolute",inset:0}}/>
                {file ? <div>{file.name}</div> : <div>Drop resume here</div>}
              </div>
              <textarea placeholder="or paste text..." value={pasteText} onChange={e=>setPasteText(e.target.value)} style={{marginTop:"1rem", minHeight:80}} />
            </div>
            
            <div className="card">
              <div className="card-label">Experience Level</div>
              <div className="levels">
                {LEVELS.map(l => (
                  <div key={l.id} className={`level-card ${level === l.id ? "selected" : ""}`} onClick={() => setLevel(l.id)}>
                    {l.icon} {l.name}
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <button className="btn-analyze" onClick={analyze} disabled={analyzing}>
                {analyzing ? "Analyzing..." : "Analyze Resume"}
              </button>
              {error && <div className="err" style={{marginTop:"1rem"}}>{error}</div>}
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (page === "loading") {
    return <div className="loading-screen"><div className="loading-ring"/><div className="loading-msg">{loadMsg}</div><Footer/></div>;
  }

  /* Analysis Page */
  return (
    <div className="analysis-page">
      <div className="topbar">
        <div className="topbar-logo">ResumeAI</div>
        <button className="btn-back" onClick={() => setPage("home")}>← Back</button>
      </div>
      <div className="split">
        <div className="pane-left">
          <ResumePreview file={file} fileURL={fileURL} pasteText={pasteText}/>
        </div>
        <div className="pane-right">
          <div className="tab-bar">
            {['ats', 'domain', 'improvements', 'projects', 'abilities'].map(t => (
              <div key={t} className={`tab-btn ${activeTab === t ? 'active' : ''}`} onClick={() => setActiveTab(t)}>{t.toUpperCase()}</div>
            ))}
          </div>
          <div className="scores-scroll">
            {activeTab === 'ats' && (
              <div className="inner-card">
                {scores && <div style={{textAlign:'center'}}><Ring score={scores.overall_score} size={120}/><div style={{fontSize:24, fontWeight:'bold'}}>{scores.overall_score}/100</div><div>{scores.verdict}</div></div>}
              </div>
            )}
            {activeTab === 'domain' && (
              <div className="inner-card">
                <MarkdownText text={window.Domain_Review.extractStrengths(reviewText)} streaming={streaming} active={true} />
              </div>
            )}
            {activeTab === 'improvements' && (
              <div className="inner-card">
                <MarkdownText text={window.Improvements.extractImprovements(reviewText)} streaming={false} active={true} />
              </div>
            )}
            {activeTab === 'projects' && (
              <div className="inner-card">
                <MarkdownText text={window.Project_Ideas.extractProjects(reviewText)} streaming={streaming} active={true} />
              </div>
            )}
            {activeTab === 'abilities' && (
               <div className="inner-card">
                 {adjacentRoles.map((r,i) => <div key={i} style={{marginBottom:10}}><strong>{r.role}</strong> ({r.fit_score}%): {r.reason}</div>)}
               </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
