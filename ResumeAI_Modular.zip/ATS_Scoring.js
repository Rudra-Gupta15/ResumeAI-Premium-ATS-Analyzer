/**
 * ATS_Scoring.js
 * Logic for calculating ATS scores and generating section-specific feedback.
 */

window.ATS_Scoring = {
  getPrompt: (finalDomain, levelConf, resumeText, parsedSections) => {
    return `You are an ATS (Applicant Tracking System) expert and resume reviewer with 10 years of experience.

The candidate is targeting the role: "${finalDomain}"
Experience level: ${levelConf.criteria}
LEVEL-SPECIFIC SCORING: ${levelConf.scoringRules}

CRITICAL SCORING RULES - BE REALISTIC AND HONEST:
- Avoid "score compression". Resumes should span the full 0-100 range.
- If a resume is generic or lacks impact, do not be afraid to score below 50.
- The "Overall ATS Score" MUST be a realistic reflection of the individual section scores.
- Strictly follow the SCORING ETHOS provided for the candidate's level.

PENALTY CHECKLIST (Apply these strictly):
- No relevant skills for ${finalDomain}: Max section score is 40.
- No quantified impact (numbers, %, $): Overall score cannot exceed 65.
- Poor formatting or unprofessional language: Deduct 15 points from Overall.
- No projects or experience shown: Overall score cannot exceed 40.

SECTION-COUNT BENCHMARKS (Overall score depends on completeness):
- 2 sections with high quality content = 65+ (Solid profile)
- 3 sections with high quality content = 75+ (Strong profile)
- 4+ sections with high quality content = 85+ (Exceptional profile)
(Note: Valid work experience often covers the need for internships. Do not penalize if experience is strong.)

SCORING GUIDELINES BY SECTION:
- **Skills**: Score based on relevance to ${finalDomain}. Generic skills (MS Office) = low score. Role-specific tools = high score.
- **Experience**: Score based on relevance and impact. Relevant roles with achievements = high score.
- **Projects**: Score based on technical depth. "To-do app" = 30-40. Complex, unique apps = 70-90.
- **Education**: Relevant degree = 75-85. Irrelevant degree = 45-55.
- **Internship**: Relevant ones = 70-85. If work experience is present, this section is OPTIONAL and should NOT penalize the overall score or be flagged as a critical issue.
- **Certificate**: Credible industry certs = 70-90. Generic courses = 40-50.
- **Extracurricular**: Be lenient. 1 item = 60, 2 items = 70, 3 items = 80, 4+ items = 90+. Always check quality; leadership roles or activities highly relevant to ${finalDomain} should receive a bonus.

Return ONLY valid JSON with ATS scores. No markdown.

{
  "overall_score": 55,
  "ats_compatibility": 60,
  "profile_scores": {
    "email": { "present": true, "score": 90, "feedback": "Professional format" },
    "github": { "present": true, "score": 100, "feedback": "Included" },
    "linkedin": { "present": true, "score": 100, "feedback": "Included" },
    "portfolio": { "present": false, "score": 0, "feedback": "Missing" },
    "kaggle": { "present": false, "score": 0, "feedback": "Missing" },
    "hackerrank": { "present": false, "score": 0, "feedback": "Missing" }
  },
  "section_scores": {
    "skills": { "score": 45, "feedback": "Missing core domain-specific tools for ${finalDomain}." },
    "experience": { "score": 50, "feedback": "Lacks quantified impact. Uses generic descriptions." },
    "education": { "score": 70, "feedback": "Relevant degree but missing honors/distinction." },
    "projects": { "score": 30, "feedback": "Only basic school assignments found." },
    "internship": { "score": 0, "feedback": "Not found (Optional if experienced)" },
    "certificate": { "score": 40, "feedback": "Only generic course completions found." },
    "extracurricular": { "score": 20, "feedback": "No relevant participation." }
  },
  "strengths": ["specific strength 1", "specific strength 2"],
  "critical_issues": ["specific issue 1", "specific issue 2"],
  "verdict": "2 sentence professional assessment - BE BLUNT if the resume is weak."
}

RAW RESUME TEXT:
${resumeText.slice(0, 2000)}

PARSED SECTIONS (JSON):
${JSON.stringify(parsedSections, null, 2).slice(0, 4000)}

JSON only:`;
  },

  applyExperienceBonus: (parsedScores, totalMonths) => {
    const months = parseInt(totalMonths) || 0;
    let experienceBonus = 0;
    if (months >= 36) experienceBonus = 10;
    else if (months >= 24) experienceBonus = 7;
    else if (months >= 12) experienceBonus = 5;
    else if (months >= 6) experienceBonus = 3;

    if (experienceBonus > 0) {
      parsedScores.overall_score = Math.min(100, (parsedScores.overall_score || 0) + experienceBonus);
      if (!parsedScores.strengths) parsedScores.strengths = [];
      const yearsText = months >= 12 ? `${(months/12).toFixed(1)} years` : `${months} months`;
      parsedScores.strengths.push(`Experience Bonus: +${experienceBonus} points for ${yearsText} of experience`);
    }
    return parsedScores;
  }
};
